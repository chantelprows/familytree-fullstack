package DataTransfer;

/**
 * All event request class
 */

public class AllEventRequest {

    private String authToken;

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }
}
