package DataTransfer;

/**
 * Single event request class
 */

public class SingleEventRequest {

    private String eventID;
    private String authToken;

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }
}
