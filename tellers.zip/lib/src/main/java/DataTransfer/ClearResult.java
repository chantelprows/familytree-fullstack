package DataTransfer;

/**
 * clear result class
 */

public class ClearResult {

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
